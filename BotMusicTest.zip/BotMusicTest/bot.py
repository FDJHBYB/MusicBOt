import discord
import yt_dlp as youtube_dl
import asyncio
import functools
import os
import aiohttp
from discord.ui import Button, View


# Suppress yt-dlp bug-report messages
youtube_dl.utils.bug_reports_message = lambda: ''

# ytdl options for high-quality audio
ytdl_format_options = {
    'format': 'bestaudio/best',
    'noplaylist': True,
    'quiet': True,
    'default_search': 'auto',
}
ffmpeg_options = {'options': '-vn -b:a 320k'}
ytdl = youtube_dl.YoutubeDL(ytdl_format_options)

# Bot configuration
TOKEN = os.getenv('TOKEN')
VOICE_CHANNEL_ID = int(os.getenv('VOICE_CHANNEL_ID'))
TEXT_CHANNEL_ID = int(os.getenv('TEXT_CHANNEL_ID'))

intents = discord.Intents.default()
intents.message_content = True
client = discord.Client(intents=intents)

# State
client.play_history = []
client.queue = []
client.current_volume = 0.5
client.loop_flag = False
client.stopped = False
client.current_controls_msg = None

client.target_channel_id = VOICE_CHANNEL_ID

@client.event
async def on_voice_state_update(member, before, after):
    # We only track sound status changes for the bot itself
    if member.id != client.user.id:
        return

    target = client.get_channel(client.target_channel_id)
    if target is None:
        return

    # Get the VoiceClient object if it's connected
    vc = discord.utils.get(client.voice_clients, guild=member.guild)

    # If the bot is expelled (separated from the channel)
    if after.channel is None:
        try:
            await target.connect()
            print(f"Reconnected to {target.name}")
        except Exception as e:
            print(f"❌ Failed to reconnect: {e}")

    # If the bot moves to another channel
    elif after.channel.id != client.target_channel_id:
        if vc:
            try:
                await vc.move_to(target)
                print(f"Moved back to {target.name}")
            except Exception as e:
                print(f"❌ Failed to move back: {e}")

async def extract_info(query: str, download: bool = False):
    loop = asyncio.get_event_loop()
    func = functools.partial(ytdl.extract_info, query, download)
    return await loop.run_in_executor(None, func)

def _after_play(vc, source_factory):
    def callback(error=None):
        if error:
            print(f"Player error: {error}")
            return
        if client.stopped:
            client.stopped = False
            return
        if client.loop_flag:
            vc.play(source_factory(), after=callback)
            return
        if client.queue:
            next_info = client.queue.pop(0)
            client.play_history.append(next_info['title'])
            if len(client.play_history) > 10:
                client.play_history.pop(0)
            def make_src():
                return discord.PCMVolumeTransformer(
                    discord.FFmpegPCMAudio(next_info['url'], **ffmpeg_options),
                    volume=client.current_volume
                )
            vc.play(make_src(), after=callback)
            asyncio.create_task(_update_controls(vc, next_info))
    return callback

async def _update_controls(vc, info):
    minutes, seconds = divmod(info.get('duration', 0) or 0, 60)
    desc_url = info.get('webpage_url') or info['url']
    embed = discord.Embed(
        title=f"🎶 Now Playing: {info['title']}",
        description=desc_url,
        color=discord.Color.blue()
    )
    embed.add_field(name="Duration", value=f"{minutes}:{seconds:02d}", inline=False)
    if client.queue:
        queue_desc = "\n".join(f"{i+1}. {q['title']}" for i, q in enumerate(client.queue))
        embed.add_field(name="⏳ Up Next", value=queue_desc, inline=False)
    if client.current_controls_msg:
        try:
            await client.current_controls_msg.edit(embed=embed, view=client.current_controls_msg.view)
        except discord.NotFound:
            pass

async def embed_reply(message: discord.Message, title: str, description: str = "", color=discord.Color.blue()):
    embed = discord.Embed(title=title, description=description, color=color)
    await message.reply(embed=embed)

async def embed_interaction(interaction: discord.Interaction, title: str,
                            description: str = "", color=discord.Color.blue(),
                            ephemeral: bool = False):
    embed = discord.Embed(title=title, description=description, color=color)
    if ephemeral:
        await interaction.response.send_message(embed=embed, ephemeral=True)
    else:
        await interaction.response.send_message(embed=embed)

class MusicControls(View):
    def __init__(self, vc: discord.VoiceClient):
        super().__init__(timeout=None)
        self.vc = vc

    async def _edit_controls(self, interaction, info):
        minutes, seconds = divmod(info.get('duration', 0) or 0, 60)
        desc_url = info.get('webpage_url') or info['url']
        embed = discord.Embed(
            title=f"🎶 Now Playing: {info['title']}",
            description=desc_url,
            color=discord.Color.blue()
        ).add_field(name="Duration", value=f"{minutes}:{seconds:02d}", inline=False)
        if client.queue:
            embed.add_field(
                name="⏳ Up Next",
                value="\n".join(f"{i+1}. {q['title']}" for i, q in enumerate(client.queue)),
                inline=False
            )
        try:
            await interaction.response.edit_message(embed=embed, view=self)
        except discord.InteractionResponded:
            await interaction.edit_original_response(embed=embed, view=self)
        client.current_controls_msg = interaction.message

    @discord.ui.button(emoji="🔄", style=discord.ButtonStyle.secondary, row=0, custom_id="restart")
    async def restart(self, interaction: discord.Interaction, button: Button):
        if not client.play_history:
            return await embed_interaction(interaction, "⚠️ No track to restart.", color=discord.Color.red(), ephemeral=True)

        # 1) We postpone the response to avoid the time limit
        await interaction.response.defer()

        last = client.play_history[-1]
        client.stopped = True
        if self.vc.is_playing():
            self.vc.stop()

        # Try YT then SC
        try:
            data = await extract_info(last, download=False)
            info_d = data if 'url' in data else data['entries'][0]
        except Exception:
            try:
                search = await extract_info(f"scsearch5:{last}", download=False)
                info_d = (search.get('entries') or [])[0]
            except Exception:
                return await interaction.followup.send("⚠️ Couldn't fetch track.", ephemeral=True)

        info = {
            'title': info_d['title'],
            'url': info_d['url'],
            'webpage_url': info_d.get('webpage_url'),
            'duration': info_d.get('duration', 0)
        }

        def src():
            return discord.PCMVolumeTransformer(
                discord.FFmpegPCMAudio(info['url'], **ffmpeg_options),
                volume=client.current_volume
            )
        self.vc.play(src(), after=_after_play(self.vc, src))

        # 2) Set up the new Embed
        minutes, seconds = divmod(info['duration'] or 0, 60)
        em = discord.Embed(
            title=f"🎶 Now Playing: {info['title']}",
            description=info['webpage_url'] or info['url'],
            color=discord.Color.blue()
        ).add_field(name="Duration", value=f"{minutes}:{seconds:02d}", inline=False)
        if client.queue:
            em.add_field(
                name="⏳ Up Next",
                value="\n".join(f"{i+1}. {q['title']}" for i, q in enumerate(client.queue)),
                inline=False
            )

        # 3) Modification of the original deferred response
        await interaction.edit_original_response(embed=em, view=self)
        client.current_controls_msg = interaction.message

        # 4) Send a follow-up message
        await interaction.followup.send(f"🔄 Restarted **{last}**", ephemeral=True)

    @discord.ui.button(emoji="⏹️", style=discord.ButtonStyle.secondary, row=0, custom_id="stop")
    async def stop(self, interaction, button):
        client.stopped = True
        client.queue.clear()
        if self.vc.is_playing():
            self.vc.stop()
        await embed_interaction(interaction, "⏹️ Playback stopped and queue cleared.", color=discord.Color.red(), ephemeral=True)

    @discord.ui.button(emoji="⏭️", style=discord.ButtonStyle.secondary, row=0, custom_id="next")
    async def next(self, interaction, button):
        if not client.queue:
            return await embed_interaction(interaction, "⚠️ No next track.", color=discord.Color.red(), ephemeral=True)
        if self.vc.is_playing():
            self.vc.stop()

        nxt = client.queue.pop(0)
        client.play_history.append(nxt['title'])
        if len(client.play_history) > 10:
            client.play_history.pop(0)

        def src2():
            return discord.PCMVolumeTransformer(
                discord.FFmpegPCMAudio(nxt['url'], **ffmpeg_options),
                volume=client.current_volume
            )
        self.vc.play(src2(), after=_after_play(self.vc, src2))
        await self._edit_controls(interaction, nxt)

    @discord.ui.button(emoji="📋", style=discord.ButtonStyle.secondary, row=0, custom_id="history")
    async def history(self, interaction, button: Button):
        if not client.play_history:
            desc = "No tracks played yet."
        else:
            desc = "\n".join(f"{i+1}. {t}" for i, t in enumerate(client.play_history))
        embed = discord.Embed(title="📋 Recent Tracks", description=desc, color=discord.Color.dark_gray())
        await interaction.response.send_message(embed=embed, ephemeral=True)

@client.event
async def on_ready():
    print(f"Logged in as {client.user}")
    try:
        ch = client.get_channel(VOICE_CHANNEL_ID)
        if isinstance(ch, discord.VoiceChannel):
            await ch.connect()
    except Exception as e:
        print(f"Error connecting: {e}")

@client.event
async def on_message(message: discord.Message):
    if message.author.bot or message.channel.id != TEXT_CHANNEL_ID:
        return

    txt = message.content.strip()
    low = txt.lower()

        # === Change Banner/Avatar command ===
    if low.startswith('!setbanner'):
        # Validity for Owner only
        if not message.guild or message.author.id != message.guild.owner_id:
            return await embed_reply(
                message,
                "⚠️This command is intended for the server owner only.",
                color=discord.Color.red()
            )

        # 1) We ask the user to send the image or its link
        await embed_reply(
            message,
            "📥 EThe new banner picture is kindly sent",
            "You can attach the image directly or send its link in the next message.",
            color=discord.Color.blue()
        )
        def check(m: discord.Message):
            return m.author == message.author and m.channel == message.channel

        try:
            resp = await client.wait_for('message', check=check, timeout=60)
        except asyncio.TimeoutError:
            return await embed_reply(
                message,
                "⚠️ Timeout",
                "I didn't receive a picture within a minute.",
                color=discord.Color.red()
            )

        # 2) We specify the link to the image
        if resp.attachments:
            img_url = resp.attachments[0].url
        else:
            img_url = resp.content.strip()

        # 3) We bring the bites
        async with aiohttp.ClientSession() as session:
            async with session.get(img_url) as r:
                if r.status != 200:
                    return await embed_reply(
                        message,
                        "⚠️ Failed to fetch image",
                        f"Response Status: {r.status}",
                        color=discord.Color.red()
                    )
                img_bytes = await r.read()

        # 4) We update the bot avatar
        try:
            await client.user.edit(avatar=img_bytes)
            await embed_reply(
                message,
                "✅ Bot Avatar has been successfully updated!",
                color=discord.Color.green()
            )
        except Exception as e:
            await embed_reply(
                message,
                "⚠️ Avatar update failed",
                str(e),
                color=discord.Color.red()
            )

        return

    # 3) !setname command — put this first
    if low.startswith('!setname'):
        # Validity for the owner only
        if not message.guild or message.author.id != message.guild.owner_id:
            return await embed_reply(
                message,
                "⚠️ This command is intended for the server owner only.",
                color=discord.Color.red()
            )

        parts = txt.split()
        # Make sure the bot mention
        if client.user not in message.mentions:
            return await embed_reply(
                message,
                "⚠️ Please mention me to set my name.",
                color=discord.Color.red()
            )
        # Make sure you have the new name
        if len(parts) < 3:
            return await embed_reply(
                message,
                "⚠️ Usage: `!setname @Bot NewNickname`",
                color=discord.Color.red()
            )

        new_nick = " ".join(parts[2:])
        try:
            await message.guild.me.edit(nick=new_nick)
            await embed_reply(
                message,
                "✅ Nickname changed to",
                new_nick,
                color=discord.Color.green()
            )
        except Exception as e:
            await embed_reply(
                message,
                "⚠️ Failed to change nickname:",
                str(e),
                color=discord.Color.red()
            )
        return
    
    if low in ('p', 'ش'):
        return await embed_reply(
            message,
            "⚠️ You must write the song or its link.",
            color=discord.Color.red()
        )

    if low.startswith(('p ', 'ش ')):
        q = txt[2:].strip()
        await embed_reply(message, "🔍 Searching for:", q)
        vc = discord.utils.get(client.voice_clients, guild=message.guild)
        if not vc or not vc.is_connected():
            try:
                vc = await client.get_channel(VOICE_CHANNEL_ID).connect()
            except Exception as e:
                return await embed_reply(message, "⚠️ Connection failed:", str(e), color=discord.Color.red())

        try:
            if q.startswith(('http://','https://')):
                d = await extract_info(q, download=False)
                idata = d if 'url' in d else d['entries'][0]
            else:
                s = await extract_info(f"ytsearch1:{q}", download=False)
                idata = s['entries'][0]
        except Exception as e:
            print("YT failed:", e)
            try:
                s2 = await extract_info(f"scsearch5:{q}", download=False)
                entries = s2.get('entries') or []
                idata = entries[0]
            except Exception as e2:
                print("SC failed:", e2)
                return await embed_reply(message, "⚠️ Fetch error (YT & SC):", str(e2), color=discord.Color.red())

        info = {
            'title': idata['title'],
            'url': idata['url'],
            'webpage_url': idata.get('webpage_url'),
            'duration': idata.get('duration', 0)
        }

        if vc.is_playing():
            client.queue.append(info)
            emq = discord.Embed(title="🔄 Added to Queue", description=info['title'], color=discord.Color.gold())
            qdesc = "\n".join(f"{i+1}. {x['title']}" for i, x in enumerate(client.queue))
            emq.add_field(name="⏳ Full Queue", value=qdesc, inline=False)
            await message.reply(embed=emq)
            return
        else:
            client.stopped = False
            def mk():
                return discord.PCMVolumeTransformer(
                    discord.FFmpegPCMAudio(info['url'], **ffmpeg_options),
                    volume=client.current_volume
                )
            vc.play(mk(), after=_after_play(vc, mk))
            client.play_history.append(info['title'])
            if len(client.play_history) > 10:
                client.play_history.pop(0)

            mins, secs = divmod(info['duration'] or 0, 60)
            em2 = discord.Embed(
                title=f"🎶 Now Playing: {info['title']}",
                description=info['webpage_url'] or info['url'],
                color=discord.Color.blue()
            ).add_field(name="Duration", value=f"{mins}:{secs:02d}", inline=False)
            if client.queue:
                em2.add_field(
                    name="⏳ Up Next",
                    value="\n".join(f"{i+1}. {y['title']}" for i, y in enumerate(client.queue)),
                    inline=False
                )

            em2.set_footer(text=f"Requested by: {message.author.display_name}")
            if client.current_controls_msg:
                try:
                    await client.current_controls_msg.edit(view=None)
                except:
                    pass

            msg = await message.reply(embed=em2, view=MusicControls(vc))
            client.current_controls_msg = msg

            

    if low in ('s', 'س'):
        client.stopped = True
        client.queue.clear()
        vc = discord.utils.get(client.voice_clients, guild=message.guild)
        if vc and vc.is_playing():
            vc.stop()
        await embed_reply(
            message,
            "⏹️ Playback stopped and queue cleared.",
            color=discord.Color.red()
        )
        return

        # If user types 'v' or 'ف' without value
    if low in ('v', 'ف'):
        return await embed_reply(
            message,
            "⚠️ Usage: `v <0-100>`",
            color=discord.Color.red()
        )

    # Sound adjustment command: 'V' or 'ف'
    if low.startswith(('v ', 'ف ')):
        try:
            # We read the number after the letter
            lvl = int(txt[1:].strip())
            lvl = max(0, min(100, lvl))
            client.current_volume = lvl / 100
            vc = discord.utils.get(client.voice_clients, guild=message.guild)
            if vc and hasattr(vc.source, 'volume'):
                vc.source.volume = client.current_volume
            await embed_reply(
                message,
                "🔊 Volume set to",
                f"{lvl}%",
                color=discord.Color.green()
            )
        except:
            return await embed_reply(
                message,
                "⚠️ Usage: `v <0-100>`",
                color=discord.Color.red()
            )
        return


    if low in ('l', 'ل'):
        client.loop_flag = not client.loop_flag
        stat = "🔁 Loop enabled." if client.loop_flag else "⏹️ Loop disabled."
        await embed_reply(message, stat, color=discord.Color.green())
        return

    if low == 'ping':
        await embed_reply(message, "📶 Pong! Latency:", f"{round(client.latency*1000)} ms", color=discord.Color.blue())

    if low in ('help', 'مساعده'):
        help_embed = discord.Embed(
            title="📬 تعليمات البوت / Bot Instructions",
            color=discord.Color.blue()
        )

        ## for AraArabic and English
        help_embed.add_field(
            name="🇸🇦 عربي",
            value=(
                "`p | ش <اسم الأغنية أو رابط>` – تشغيل أو إضافة للانتظار\n"
                "`s | س ` – إيقاف التشغيل ومسح قائمة الانتظار\n"
                "`v | ف  <0-100>` – ضبط مستوى الصوت\n"
                "`l | ل ` – تكرار التشغيل\n"
                "`ping` – قياس الاستجابة\n"
                "`!setname` – تغيير اسم البوت للاونر فقط\n"
                "`!setname` – تغيير اسم صوره البوت للاونر فقط\n"
                "`help | مساعده ` – عرض هذه القائمة"
            ),
            inline=False
        )
        help_embed.add_field(
            name="🇺🇸 English",
            value=(
                "`p | ش  <song name or URL>` – Play or queue a track\n"
                "`s | س ` – Stop playback and clear queue\n"
                "`v | ف  <0-100>` – Set volume\n"
                "`l | ل ` – Toggle loop mode\n"
                "`ping` – Check latency\n"
                "`!setname` – Change Bot Name For Owner Server\n"
                "`!setbanner` – Change Bot Banner For Owner Server\n"
                "`help | مساعده` – Show this message"
            ),
            inline=False
        )
        await message.author.send(embed=help_embed)

        # Thank you letter and link
        credit_embed = discord.Embed(
            description=(
                "Bot developed by **ABUMAJED**\n"
                "Join our server: https://discord.gg/a7b"
            ),
            color=discord.Color.green()
        )
        await message.author.send(embed=credit_embed)

        await embed_reply(message, "📬 Check your DMs for help!", color=discord.Color.blue())

client.run(TOKEN)